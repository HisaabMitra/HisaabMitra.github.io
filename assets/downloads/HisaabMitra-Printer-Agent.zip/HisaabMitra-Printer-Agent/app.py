from flask import Flask, jsonify, request
from flask_cors import CORS
import win32print
import win32ui
import win32con

app = Flask(__name__)

# CORS Fully Configured
CORS(app, resources={r"/*": {"origins": "*", "methods": ["GET", "POST", "OPTIONS"], "allow_headers": ["Content-Type"]}})

@app.route("/health", methods=["GET"])
def health():
    return jsonify({
        "status": "running",
        "service": "HisaabMitra Printer Agent"
    })

@app.route("/printers", methods=["GET"])
def printers():
    try:
        flags = (
            win32print.PRINTER_ENUM_LOCAL |
            win32print.PRINTER_ENUM_CONNECTIONS
        )
        printers = []
        default_printer = ""
        try:
            default_printer = win32print.GetDefaultPrinter()
        except:
            pass

        for printer in win32print.EnumPrinters(flags):
            name = printer[2]
            printers.append({
                "name": name,
                "default": name == default_printer
            })
        return jsonify({"success": True, "printers": printers})
    except Exception as ex:
        return jsonify({"success": False, "message": str(ex)})

# 🎯 🖨️ SILENT PRINT ENDPOINT (Pure RAW Hardware Mode - No Dialogue Popup)
@app.route("/print", methods=["POST", "OPTIONS"])
def silent_print():
    if request.method == "OPTIONS":
        return jsonify({"success": True}), 200

    try:
        data = request.json or {}
        printer_name = data.get("printer_name")
        html_content = data.get("content") # Isme hamara receipt ka raw string text aayega

        if not printer_name or not html_content:
            return jsonify({"success": False, "message": "Missing printer_name or content"}), 400

        # HTML tags ko text printer ke liye clean karna (Agar text printer raw text mangta hai)
        # Lekin agar aap thermal printer par bhej rhe hain toh hum direct RAW string data ko use karenge.
        import re
        def clean_html(raw_html):
            cleanr = re.compile('<.*?>')
            cleantext = re.sub(cleanr, '', raw_html)
            # Faltu ki spaces aur blank lines clean karke alignment set karna
            lines = [line.strip() for line in cleantext.split('\n') if line.strip()]
            return '\n'.join(lines)

        printable_text = clean_html(html_content)

        # 🌟 Win32 RAW Printing: Yeh direct hardware queue me jata hai, koi UI nahi khul sakta!
        hPrinter = win32print.OpenPrinter(printer_name)
        try:
            # RAW data type batata hai ki seedha machine code bhejo, windows settings bypass karo
            hJob = win32print.StartDocPrinter(hPrinter, 1, ("HisaabMitra Silent POS", None, "RAW"))
            win32print.StartPagePrinter(hPrinter)
            
            # Send text stream directly to thermal/passbook printer
            win32print.WritePrinter(hPrinter, printable_text.encode('utf-8'))
            
            win32print.EndPagePrinter(hPrinter)
            win32print.EndDocPrinter(hPrinter)
        finally:
            win32print.ClosePrinter(hPrinter)
            
        return jsonify({"success": True, "message": f"Print job sent directly to hardware queue of '{printer_name}'"})
            
    except Exception as ex:
        return jsonify({"success": False, "message": f"Hardware spooler error: {str(ex)}"}), 500

if __name__ == "__main__":
    app.run(
        host="127.0.0.1",
        port=5000,
        debug=False
    )