Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "cmd /c run_agent.bat", 0, False